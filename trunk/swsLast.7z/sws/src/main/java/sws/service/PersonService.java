package sws.service;

import sws.model.Person;

/**
 * User: Andrey Popov
 * Date: 08.12.2010
 * Time: 16:25:31
 */
public interface PersonService {
    Person getPersonById(int id);
}
